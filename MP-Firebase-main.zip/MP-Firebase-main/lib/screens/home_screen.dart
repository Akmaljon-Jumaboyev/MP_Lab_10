import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/auth_service.dart';
import '../widgets/custom_button.dart';
import 'login_screen.dart';
import 'profile_update_screen.dart';

class HomeScreen extends StatelessWidget {
  final User user;

  const HomeScreen({super.key, required this.user});

  @override
  Widget build(BuildContext context) {
    final displayName = user.displayName ?? "";
    final photoUrl = user.photoURL;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Home"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const SizedBox(height: 30),
            if (photoUrl != null)
              CircleAvatar(
                radius: 40,
                backgroundImage: NetworkImage(photoUrl),
              )
            else
              const CircleAvatar(
                radius: 40,
                child: Icon(Icons.person, size: 40),
              ),
            const SizedBox(height: 20),
            Text(
              "Hello, ${user.email}!",
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            if (displayName.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(
                "Name: $displayName",
                style: const TextStyle(fontSize: 16),
              ),
            ],
            const SizedBox(height: 40),
            CustomButton(
              text: "Update Profile",
              onPressed: () async {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const ProfileUpdateScreen(),
                  ),
                );
              },
            ),
            const SizedBox(height: 20),
            CustomButton(
              text: "Logout",
              onPressed: () async {
                await AuthService().logout();
                if (context.mounted) {
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const LoginScreen(),
                    ),
                    (route) => false,
                  );
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}
